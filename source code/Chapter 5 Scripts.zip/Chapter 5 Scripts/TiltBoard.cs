﻿using UnityEngine;
using System.Collections;

public class TiltBoard : MonoBehaviour {
	
	public float factor = 0.6f; // adjustment
	Vector3 v3StartPos; // mouse location
	Vector3 v3StartRot; // board orientation

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	void OnMouseDown(){
		v3StartPos = Input.mousePosition; // starting location of the cursor
		v3StartRot = transform.eulerAngles; // current orientation of board
	}

	void OnMouseDrag(){
		Vector3 v3T  = Input.mousePosition; // get the current cursor position
		transform.eulerAngles = v3StartRot + (Vector3.left * (v3StartPos - v3T).y * factor) + (Vector3.forward * (v3StartPos - v3T).x * factor);
	}

}
